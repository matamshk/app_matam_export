import os
import json
from http.server import SimpleHTTPRequestHandler, HTTPServer
import urllib.parse

# Set working directory to the script's location
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# Path to the JSON database
DB_FILE = 'database.json'

# Simple Authentication
ADMIN_PASSWORD = 'admin123'
ADMIN_TOKEN = 'secure_admin_token_2026_xyz'

# Initialize database if it doesn't exist
if not os.path.exists(DB_FILE):
    with open(DB_FILE, 'w', encoding='utf-8') as f:
        json.dump({
            "bookings": [],
            "custom_occasions": [],
            "hijri_offset": 0,
            "settings": {"whatsapp_phone": "97300000000"},
            "users": [{"id": "superadmin1", "username": "admin", "password": "admin123", "role": "superadmin", "name": "المدير العام"}],
            "sessions": {}
        }, f, ensure_ascii=False, indent=2)

def load_db():
    try:
        with open(DB_FILE, 'r', encoding='utf-8') as f:
            db = json.load(f)
            if "users" not in db:
                db["users"] = [{"id": "superadmin1", "username": "admin", "password": "admin123", "role": "superadmin", "name": "المدير العام"}]
            if "sessions" not in db:
                db["sessions"] = {}
            return db
    except Exception:
        return {"bookings": [], "custom_occasions": [], "hijri_offset": 0, "settings": {}, "users": [{"id": "superadmin1", "username": "admin", "password": "admin123", "role": "superadmin", "name": "المدير العام"}], "sessions": {}}

def save_db(data):
    with open(DB_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

class CustomAPIHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        # Prevent caching of API and HTML
        if self.path.startswith('/api/') or self.path.endswith('.html') or self.path.endswith('.js'):
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
        super().end_headers()

    def do_GET(self):
        if self.path.startswith('/api/data'):
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            db = load_db()
            self.wfile.write(json.dumps(db).encode('utf-8'))
        else:
            # Fallback to serving static files
            super().do_GET()

    def do_POST(self):
        # Parse content length
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8')
        
        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            self.send_response(400)
            self.end_headers()
            return

        db = load_db()

        if self.path == '/api/save_booking':
            # Prepend the short booking to the top
            db['bookings'].insert(0, payload)
            save_db(db)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))

        elif self.path == '/api/save_custom_occasion':
            db['custom_occasions'].append(payload)
            save_db(db)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))

        elif self.path == '/api/save_offset':
            db['hijri_offset'] = payload.get('offset', 0)
            save_db(db)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))

        elif self.path == '/api/update_booking_status':
            booking_id = payload.get('id')
            new_status = payload.get('status')
            for b in db['bookings']:
                if str(b.get('id')) == str(booking_id):
                    b['status'] = new_status
                    break
            save_db(db)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))

        elif self.path == '/api/delete_booking':
            booking_id = payload.get('id')
            db['bookings'] = [b for b in db['bookings'] if str(b.get('id')) != str(booking_id)]
            save_db(db)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))

        elif self.path == '/api/edit_booking':
            booking_id = payload.get('id')
            for b in db['bookings']:
                if str(b.get('id')) == str(booking_id):
                    if 'name' in payload: b['name'] = payload['name']
                    if 'phone' in payload: b['phone'] = payload['phone']
                    if 'date' in payload: b['date'] = payload['date']
                    break
            save_db(db)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))

        elif self.path == '/api/save_settings':
            if 'settings' not in db:
                db['settings'] = {}
            db['settings'].update(payload.get('settings', {}))
            save_db(db)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))

        elif self.path == '/api/login':
            import uuid
            username = payload.get('username')
            password = payload.get('password')
            user = next((u for u in db['users'] if u.get('username') == username and u.get('password') == password), None)
            
            if user:
                token = uuid.uuid4().hex
                db['sessions'][token] = {"user_id": user['id'], "role": user['role'], "name": user['name']}
                save_db(db)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "success", "token": token, "role": user['role'], "name": user['name']}).encode('utf-8'))
            else:
                self.send_response(401)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "error", "message": "Invalid password"}).encode('utf-8'))

        elif self.path == '/api/verify':
            token = payload.get('token')
            if token in db['sessions']:
                user_info = db['sessions'][token]
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "success", "role": user_info['role'], "name": user_info.get('name')}).encode('utf-8'))
            else:
                self.send_response(401)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "error"}).encode('utf-8'))
                
        elif self.path == '/api/get_users':
            token = payload.get('token')
            if token in db['sessions'] and db['sessions'][token]['role'] == 'superadmin':
                safe_users = [{"id": u.get("id"), "username": u.get("username"), "name": u.get("name", ""), "role": u.get("role")} for u in db['users']]
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "success", "users": safe_users}).encode('utf-8'))
            else:
                self.send_response(403)
                self.end_headers()

        elif self.path == '/api/save_user':
            import uuid
            token = payload.get('token')
            if token in db['sessions'] and db['sessions'][token]['role'] == 'superadmin':
                user_data = payload.get('user')
                user_id = user_data.get('id', '')
                if not user_id:
                    user_data['id'] = 'user_' + uuid.uuid4().hex[:8]
                    db['users'].append(user_data)
                else:
                    for u in db['users']:
                        if u.get('id') == user_id:
                            u['username'] = user_data.get('username')
                            if user_data.get('password'):
                                u['password'] = user_data.get('password')
                            u['name'] = user_data.get('name')
                            u['role'] = user_data.get('role')
                            break
                save_db(db)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))
            else:
                self.send_response(403)
                self.end_headers()

        elif self.path == '/api/delete_user':
            token = payload.get('token')
            if token in db['sessions'] and db['sessions'][token]['role'] == 'superadmin':
                user_id = payload.get('id')
                if user_id != db['sessions'][token]['user_id']: # prevent delete self
                    db['users'] = [u for u in db['users'] if u.get('id') != user_id]
                    save_db(db)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))
            else:
                self.send_response(403)
                self.end_headers()

        else:
            self.send_response(404)
            self.end_headers()

def run(port=8080):
    server_address = ('127.0.0.1', port)
    httpd = HTTPServer(server_address, CustomAPIHandler)
    print(f"Server with Database API running at http://127.0.0.1:{port}")
    httpd.serve_forever()

if __name__ == '__main__':
    run()
